# A sharp lower general-position bound for Cartesian products

Preprint version 0.3, 15 October 2026.

**River Zhang** · ORCID 0009-0004-2437-8566 · mioqwq@hotmail.com.

Read paper/main.pdf for the complete manuscript and REPRODUCE.md for the exact verification commands. Run `python verify_manifest.py` before replay. The current PDF and source are accompanied by component licenses, source bindings, version provenance and dated verification records.

Fixed 319-vertex original-conjecture counterexample only; universal theorem is written/computer-assisted.

Version 0.3 shortens the AI use disclosure; all other manuscript text, except the version label, and all supplementary mathematical sources are unchanged from version 0.2. Earlier version-specific documents are preserved under history/. Current PDF compilation/page checks are separate from the retained mathematical and Lean execution evidence.

The manuscript and LaTeX are CC BY 4.0. Software retains its original licenses. zenodo-upload-metadata.json contains manuscript metadata; the separate draft-reservation template is not a deposit or publication. No new DOI or external submission is asserted.
