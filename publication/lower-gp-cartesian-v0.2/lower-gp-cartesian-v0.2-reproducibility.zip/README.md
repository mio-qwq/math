# A sharp lower general-position bound for Cartesian products

Author-identified preparation version 0.2, 15 October 2026. River Zhang, ORCID 0009-0004-2437-8566, mioqwq@hotmail.com.

Start with paper/main.pdf and REPRODUCE.md. This is a self-contained mathematical manuscript with a reproducibility supplement, not a journal submission, human peer-review certificate or newly registered DOI. The accepted version 0.1 mathematics is preserved; the version 0.2 update is documented in AUTHOR_VERSION_PROVENANCE.json. Old version-specific reports remain under history/v0.1/ and in the original public archive.

Run `python verify_manifest.py` before any replay. The precise original mathematical commands and Lean boundaries are in REPRODUCE.md. Current PDF build/page evidence is in verification/; historical mathematical evidence keeps its original dates.

The manuscript and LaTeX source are CC BY 4.0; existing mathematical-source/software licenses remain unchanged. zenodo-upload-metadata.json supplies final manuscript metadata for manual upload; the separate closed-access draft template is not a publication. No publish action is included in the optional draft client.
